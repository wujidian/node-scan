window.g = {
    passport: 'https://passport.168pool.com',
    nodeUrl: 'https://data.168node.com',
    cloundUrl: 'https://cloud-front-api.168node.com'
}
// window.g = {
//     passport: 'https://dev-passport.168pool.com',
//     nodeUrl: 'https://node-data-dev.168pool.com',
//     cloundUrl: 'https://dev-api.168node.com'
// }